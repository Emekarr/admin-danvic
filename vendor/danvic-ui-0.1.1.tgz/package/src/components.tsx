'use client'

import Link from 'next/link'
import type {
  ComponentType,
  HTMLAttributes,
  InputHTMLAttributes,
  ReactNode,
  TextareaHTMLAttributes,
} from 'react'
import { cloneElement, forwardRef, useEffect, useId, useRef, useState } from 'react'
import {
  AlertCircle,
  Check,
  CheckCircle2,
  ChevronDown,
  Eye,
  EyeOff,
  LoaderCircle,
} from 'lucide-react'
import clsx from 'clsx'

export function Brand({ href = '/', light = false }: { href?: string; light?: boolean }) {
  return (
    <Link href={href} className="sb-brand" data-light={light || undefined} aria-label="DANVIC home">
      <span className="sb-brand-mark" aria-hidden="true" />
      <span>DANVIC</span>
    </Link>
  )
}

export const Button = forwardRef<
  HTMLButtonElement,
  React.ButtonHTMLAttributes<HTMLButtonElement> & {
    variant?: 'primary' | 'secondary' | 'soft' | 'ghost' | 'danger'
    size?: 'sm' | 'md' | 'lg' | 'icon'
    busy?: boolean
  }
>(function Button(
  { variant = 'primary', size = 'md', busy = false, disabled, className, children, ...props },
  ref,
) {
  return (
    <button
      ref={ref}
      className={clsx('sb-button', `sb-button--${variant}`, `sb-button--${size}`, className)}
      disabled={disabled || busy}
      aria-busy={busy || undefined}
      {...props}
    >
      {busy ? <LoaderCircle className="sb-spinner" aria-hidden="true" /> : null}
      {children}
    </button>
  )
})

export const Input = forwardRef<HTMLInputElement, InputHTMLAttributes<HTMLInputElement>>(
  function Input({ className, ...props }, ref) {
    return <input ref={ref} className={clsx('sb-input', className)} {...props} />
  },
)

export const PasswordInput = forwardRef<HTMLInputElement, InputHTMLAttributes<HTMLInputElement>>(
  function PasswordInput({ className, type: _type, ...props }, ref) {
    const [visible, setVisible] = useState(false)
    return (
      <div className="sb-password-input-wrap">
        <input
          ref={ref}
          className={clsx('sb-input', 'sb-password-input', className)}
          type={visible ? 'text' : 'password'}
          {...props}
        />
        <button
          className="sb-password-toggle"
          type="button"
          aria-label={visible ? 'Hide password' : 'Show password'}
          aria-pressed={visible}
          onClick={() => setVisible((value) => !value)}
        >
          {visible ? <EyeOff aria-hidden="true" /> : <Eye aria-hidden="true" />}
        </button>
      </div>
    )
  },
)

export const CodeInput = forwardRef<HTMLDivElement, InputHTMLAttributes<HTMLInputElement>>(
  function CodeInput(
    {
      id,
      name,
      className,
      defaultValue,
      value,
      maxLength,
      pattern,
      required,
      disabled,
      readOnly,
      autoComplete,
      inputMode,
      'aria-describedby': ariaDescribedBy,
      'aria-invalid': ariaInvalid,
      onBlur: _onBlur,
      onFocus: _onFocus,
      onChange: _onChange,
      onKeyDown: _onKeyDown,
      onPaste: _onPaste,
      ...inputProps
    },
    ref,
  ) {
    const digitCount = 6
    const initialValue = String(value ?? defaultValue ?? '')
      .replace(/\D/g, '')
      .slice(0, digitCount)
    const [digits, setDigits] = useState(() =>
      [...initialValue.split(''), ...Array<string>(digitCount).fill('')].slice(0, digitCount),
    )
    const inputRefs = useRef<Array<HTMLInputElement | null>>([])
    const code = digits.join('')

    const focusDigit = (index: number) => {
      inputRefs.current[Math.max(0, Math.min(index, digitCount - 1))]?.focus()
    }

    const setCodeFrom = (startIndex: number, rawValue: string) => {
      const next = [...digits]
      rawValue
        .replace(/\D/g, '')
        .slice(0, digitCount - startIndex)
        .split('')
        .forEach((digit, offset) => {
          next[startIndex + offset] = digit
        })
      setDigits(next)
      focusDigit(Math.min(startIndex + rawValue.replace(/\D/g, '').length, digitCount - 1))
    }

    return (
      <div
        ref={ref}
        className={clsx('sb-code-input', className)}
        role="group"
        aria-describedby={ariaDescribedBy}
        aria-invalid={ariaInvalid}
      >
        <input
          className="sb-code-input-value"
          name={name}
          value={code}
          required={required}
          maxLength={maxLength ?? digitCount}
          pattern={pattern}
          disabled={disabled}
          tabIndex={-1}
          aria-hidden="true"
          readOnly
        />
        {digits.map((digit, index) => (
          <input
            key={index}
            ref={(element) => {
              inputRefs.current[index] = element
            }}
            {...inputProps}
            id={index === 0 ? id : undefined}
            className="sb-code-digit"
            type="text"
            value={digit}
            inputMode={inputMode ?? 'numeric'}
            autoComplete={index === 0 ? autoComplete : 'off'}
            maxLength={1}
            pattern="[0-9]"
            disabled={disabled}
            readOnly={readOnly}
            aria-label={`Digit ${index + 1} of ${digitCount}`}
            onChange={(event) => {
              const rawValue = event.currentTarget.value.replace(/\D/g, '')
              if (!rawValue) {
                const next = [...digits]
                next[index] = ''
                setDigits(next)
                return
              }
              setCodeFrom(index, rawValue)
            }}
            onKeyDown={(event) => {
              if (event.key === 'Backspace' && !digits[index] && index > 0) {
                const next = [...digits]
                next[index - 1] = ''
                setDigits(next)
                focusDigit(index - 1)
              } else if (event.key === 'ArrowLeft' && index > 0) {
                event.preventDefault()
                focusDigit(index - 1)
              } else if (event.key === 'ArrowRight' && index < digitCount - 1) {
                event.preventDefault()
                focusDigit(index + 1)
              }
            }}
            onPaste={(event) => {
              const pasted = event.clipboardData.getData('text').replace(/\D/g, '')
              if (!pasted) return
              event.preventDefault()
              setCodeFrom(index, pasted)
            }}
          />
        ))}
      </div>
    )
  },
)

export const Textarea = forwardRef<
  HTMLTextAreaElement,
  TextareaHTMLAttributes<HTMLTextAreaElement>
>(function Textarea({ className, ...props }, ref) {
  return <textarea ref={ref} className={clsx('sb-input', 'sb-textarea', className)} {...props} />
})

export function Field({
  label,
  required,
  hint,
  error,
  children,
}: {
  label: string
  required?: boolean
  hint?: string
  error?: string
  children: React.ReactElement<{
    id?: string
    'aria-describedby'?: string
    'aria-invalid'?: boolean
  }>
}) {
  const generatedId = useId()
  const id = children.props.id ?? generatedId
  const descriptionId = `${id}-description`
  return (
    <div className="sb-field">
      <label className="sb-label" htmlFor={id}>
        {label} {required ? <span aria-hidden="true">*</span> : null}
      </label>
      {cloneElement(children, {
        id,
        ...(hint || error ? { 'aria-describedby': descriptionId } : {}),
        ...(error ? { 'aria-invalid': true } : {}),
      })}
      {error ? (
        <p className="sb-field-error" id={descriptionId} role="alert">
          <AlertCircle aria-hidden="true" /> {error}
        </p>
      ) : hint ? (
        <p className="sb-field-hint" id={descriptionId}>
          {hint}
        </p>
      ) : null}
    </div>
  )
}

export function Select(props: React.SelectHTMLAttributes<HTMLSelectElement>) {
  return <select {...props} className={clsx('sb-input', 'sb-select', props.className)} />
}

export function CustomDropdown<T extends string>({
  value,
  onChange,
  options,
  placeholder = 'Select an option',
  id,
  name,
  'aria-describedby': ariaDescribedBy,
  'aria-invalid': ariaInvalid,
}: {
  value: T
  onChange: (value: T) => void
  options: Array<{
    value: T
    label: string
    description?: string
    icon?: ReactNode
    disabled?: boolean
  }>
  placeholder?: string
  id?: string
  name?: string
  'aria-describedby'?: string
  'aria-invalid'?: boolean
}) {
  const [open, setOpen] = useState(false)
  const dropdownRef = useRef<HTMLDivElement>(null)
  const menuId = useId()

  const selectedOption = options.find((opt) => opt.value === value)

  useEffect(() => {
    const closeOnOutsideClick = (event: MouseEvent) => {
      if (!dropdownRef.current?.contains(event.target as Node)) setOpen(false)
    }
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setOpen(false)
    }
    document.addEventListener('mousedown', closeOnOutsideClick)
    document.addEventListener('keydown', closeOnEscape)
    return () => {
      document.removeEventListener('mousedown', closeOnOutsideClick)
      document.removeEventListener('keydown', closeOnEscape)
    }
  }, [])

  const focusOption = (direction: 'first' | 'last') => {
    const enabledOptions = options.filter((option) => !option.disabled)
    const target = direction === 'first' ? enabledOptions[0] : enabledOptions.at(-1)
    if (!target) return
    requestAnimationFrame(() => {
      document.getElementById(`${menuId}-${target.value}`)?.focus()
    })
  }

  const selectOption = (option: (typeof options)[number]) => {
    if (option.disabled) return
    onChange(option.value)
    setOpen(false)
  }

  return (
    <div className="sb-custom-dropdown" ref={dropdownRef}>
      {name ? <input type="hidden" name={name} value={value} /> : null}
      <button
        id={id}
        type="button"
        className="sb-custom-dropdown-trigger"
        onClick={() => setOpen((current) => !current)}
        onKeyDown={(event) => {
          if (event.key === 'Escape') {
            setOpen(false)
            return
          }
          if (event.key === 'ArrowDown' || event.key === 'Enter' || event.key === ' ') {
            event.preventDefault()
            setOpen(true)
            focusOption('first')
          }
          if (event.key === 'ArrowUp') {
            event.preventDefault()
            setOpen(true)
            focusOption('last')
          }
        }}
        aria-expanded={open}
        aria-haspopup="listbox"
        aria-controls={open ? menuId : undefined}
        aria-describedby={ariaDescribedBy}
        aria-invalid={ariaInvalid}
      >
        {selectedOption ? (
          <span className="sb-custom-dropdown-value">
            {selectedOption.icon && (
              <span className="sb-custom-dropdown-icon">{selectedOption.icon}</span>
            )}
            <span className="sb-custom-dropdown-text">
              <strong>{selectedOption.label}</strong>
              {selectedOption.description && <small>{selectedOption.description}</small>}
            </span>
          </span>
        ) : (
          <span className="sb-custom-dropdown-placeholder">{placeholder}</span>
        )}
        <span className="sb-custom-dropdown-arrow" aria-hidden="true">
          <ChevronDown />
        </span>
      </button>
      {open && (
        <ul className="sb-custom-dropdown-menu" id={menuId} role="listbox">
          {options.map((option) => (
            <li
              key={option.value}
              role="option"
              aria-selected={value === option.value}
              className="sb-custom-dropdown-option"
            >
              <button
                id={`${menuId}-${option.value}`}
                type="button"
                className="sb-custom-dropdown-option-button"
                disabled={option.disabled}
                onClick={() => selectOption(option)}
                onKeyDown={(event) => {
                  const enabledOptions = options.filter((item) => !item.disabled)
                  const index = enabledOptions.findIndex((item) => item.value === option.value)
                  const next =
                    event.key === 'ArrowDown'
                      ? enabledOptions[index + 1] ?? enabledOptions[0]
                      : event.key === 'ArrowUp'
                        ? enabledOptions[index - 1] ?? enabledOptions.at(-1)
                        : null
                  if (next) {
                    event.preventDefault()
                    document.getElementById(`${menuId}-${next.value}`)?.focus()
                  }
                  if (event.key === 'Home') {
                    event.preventDefault()
                    focusOption('first')
                  }
                  if (event.key === 'End') {
                    event.preventDefault()
                    focusOption('last')
                  }
                  if (event.key === 'Escape') {
                    event.preventDefault()
                    setOpen(false)
                    dropdownRef.current?.querySelector<HTMLButtonElement>('.sb-custom-dropdown-trigger')?.focus()
                  }
                }}
              >
                {option.icon && <span className="sb-custom-dropdown-icon">{option.icon}</span>}
                <span className="sb-custom-dropdown-text">
                  <strong>{option.label}</strong>
                  {option.description && <small>{option.description}</small>}
                </span>
                {value === option.value ? (
                  <span className="sb-custom-dropdown-selected" aria-hidden="true">
                    <Check />
                  </span>
                ) : null}
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}

export function Card({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return <div className={clsx('sb-card', className)} {...props} />
}

export function Badge({
  children,
  tone = 'neutral',
  dot = false,
}: {
  children: ReactNode
  tone?: 'neutral' | 'blue' | 'green' | 'amber' | 'red' | 'violet'
  dot?: boolean
}) {
  return (
    <span className={clsx('sb-badge', `sb-badge--${tone}`)}>
      {dot ? <span className="sb-badge-dot" aria-hidden="true" /> : null}
      {children}
    </span>
  )
}

export function PageHeader({
  eyebrow,
  title,
  description,
  actions,
}: {
  eyebrow?: string
  title: ReactNode
  description?: string
  actions?: ReactNode
}) {
  return (
    <header className="sb-page-header">
      <div>
        {eyebrow ? <p className="sb-page-eyebrow">{eyebrow}</p> : null}
        <h1>{title}</h1>
        {description ? <p>{description}</p> : null}
      </div>
      {actions ? <div className="sb-page-actions">{actions}</div> : null}
    </header>
  )
}

export function Kpi({
  label,
  value,
  meta,
  icon,
}: {
  label: string
  value: string
  meta: string
  icon: ReactNode
}) {
  return (
    <div className="sb-kpi">
      <div className="sb-kpi-top">
        <span>{label}</span>
        <span className="sb-kpi-icon">{icon}</span>
      </div>
      <strong className="sb-kpi-value">{value}</strong>
      <span className="sb-kpi-meta">{meta}</span>
    </div>
  )
}

export function AuthLayout({
  className,
  eyebrow,
  headline,
  description,
  features,
  children,
}: {
  className?: string
  eyebrow: string
  headline: string
  description: string
  features: Array<{ icon: ComponentType<{ 'aria-hidden'?: boolean }>; label: string }>
  children: ReactNode
}) {
  return (
    <main className={clsx('sb-login', className)}>
      <section className="sb-login-panel" aria-label="DANVIC introduction">
        <Brand href="/" light />
        <div className="sb-login-copy">
          <p className="sb-page-eyebrow">{eyebrow}</p>
          <h1>{headline}</h1>
          <p>{description}</p>
        </div>
        <div className="sb-login-features">
          {features.map(({ icon: Icon, label }) => (
            <span className="sb-login-feature" key={label}>
              <Icon aria-hidden={true} /> {label}
            </span>
          ))}
        </div>
      </section>
      <section className="sb-login-form-wrap">{children}</section>
    </main>
  )
}

export function FormMessage({
  children,
  tone = 'error',
}: {
  children?: ReactNode
  tone?: 'error' | 'success' | 'info'
}) {
  if (!children) return null
  return (
    <div className="sb-form-message" data-tone={tone} role={tone === 'error' ? 'alert' : 'status'}>
      {tone === 'success' ? <CheckCircle2 aria-hidden="true" /> : null}
      <span>{children}</span>
    </div>
  )
}

export function EmptyState({
  icon,
  title,
  description,
  action,
}: {
  icon: ReactNode
  title: string
  description: string
  action?: ReactNode
}) {
  return (
    <div className="sb-empty-state">
      <span className="sb-empty-icon">{icon}</span>
      <h3>{title}</h3>
      <p>{description}</p>
      {action}
    </div>
  )
}
