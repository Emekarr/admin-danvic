import { z } from 'zod'

const plainText = (maximum: number) =>
  z
    .string()
    .trim()
    .min(1)
    .max(maximum)
    .refine((value) => !/[<>\u0000-\u0008\u000B\u000C\u000E-\u001F]/u.test(value), {
      message: 'Use plain text without markup or control characters',
    })

const hasKoboPrecision = (priceNaira: number) => {
  const priceKobo = priceNaira * 100
  return (
    Number.isSafeInteger(Math.round(priceKobo)) &&
    Math.abs(priceKobo - Math.round(priceKobo)) <=
      Number.EPSILON * Math.max(1, Math.abs(priceKobo)) * 4
  )
}

const MAX_COURSE_UPLOAD_BYTES = 1024 * 1024 * 1024

export const emailSchema = z.email().max(320)
export const passwordSchema = z.string().min(12).max(128)
export const codeSchema = z.string().regex(/^\d{6}$/, 'Enter the six-digit code')
export const tokenSchema = z.string().regex(/^[A-Za-z0-9_-]{32,256}$/)
export const idSchema = z.string().regex(/^[0-9A-HJKMNP-TV-Z]{26}$/)
export const paystackReferenceSchema = z.string().regex(/^DANVIC-[0-9A-HJKMNP-TV-Z]{26}$/)
export const paymentInitializationSchema = z.strictObject({
  paymentMethodId: idSchema.nullable().optional(),
  savePaymentMethod: z.boolean(),
})
export const certificateNumberSchema = z
  .string()
  .trim()
  .regex(/^\d{4}-\d{4}-\d{4}-\d{4}$/)

export const loginSchema = z.strictObject({
  email: emailSchema,
  password: z.string().min(1).max(128),
})
export const emptySchema = z.strictObject({})
export const forgotPasswordSchema = z.strictObject({ email: emailSchema })
export const resetPasswordSchema = z.strictObject({
  email: emailSchema,
  code: codeSchema,
  newPassword: passwordSchema,
})
export const updatePasswordSchema = z.strictObject({
  currentPassword: z.string().min(1).max(128),
  newPassword: passwordSchema,
})
export const twoFactorCodeSchema = z.strictObject({ code: codeSchema })
export const invitationSchema = z.strictObject({
  emails: z
    .array(emailSchema)
    .min(1)
    .max(50)
    .refine((emails) => new Set(emails).size === emails.length, {
      message: 'Email addresses must be unique',
    }),
})
export const courseInvitationSchema = z.strictObject({
  courseId: idSchema,
  emails: z
    .array(emailSchema)
    .min(1)
    .max(50)
    .refine((emails) => new Set(emails).size === emails.length, {
      message: 'Email addresses must be unique',
    }),
})
export const invitationTokenSchema = z.strictObject({ token: tokenSchema })
export const acceptInvitationSchema = z.strictObject({
  token: tokenSchema,
  firstName: plainText(100),
  lastName: plainText(100),
  password: passwordSchema,
})
const profileText = (maximum: number) =>
  z
    .string()
    .trim()
    .max(maximum)
    .refine((value) => !/[<>\u0000-\u0008\u000B\u000C\u000E-\u001F]/u.test(value), {
      message: 'Use plain text without markup or control characters',
    })
const httpUrl = z
  .string()
  .trim()
  .max(500)
  .url()
  .refine((value) => /^https?:\/\//iu.test(value), { message: 'Enter a valid http(s) URL' })
  .nullable()
export const authorProfileSchema = z.strictObject({
  bio: profileText(2000),
  linkedInUrl: httpUrl,
  xUrl: httpUrl,
  instagramUrl: httpUrl,
  facebookUrl: httpUrl,
  websiteUrl: httpUrl,
})
export const studentProfileSchema = z.strictObject({
  bio: profileText(2000),
  linkedInUrl: httpUrl,
  xUrl: httpUrl,
  facebookUrl: httpUrl,
  instagramUrl: httpUrl,
  youtubeUrl: httpUrl,
  websiteUrl: httpUrl,
})

export const moduleSchema = z.strictObject({
  title: plainText(200),
  content: plainText(100_000),
})
export const attachmentSchema = z.strictObject({
  attachmentPath: z
    .string()
    .regex(
      /^courses\/[0-9A-HJKMNP-TV-Z]{26}\/[0-9A-HJKMNP-TV-Z]{26}\.(pdf|jpg|png|svg|gif|webp|mp4|mov|webm|mp3|wav|m4a|ogg|txt|csv|doc|docx|ppt|pptx|xls|xlsx|zip)$/,
    ),
  moduleId: idSchema.nullable().optional(),
  fileName: plainText(200).nullable().optional(),
})
const courseAttachmentSchema = attachmentSchema.extend({
  moduleIndex: z.number().int().min(0).max(99).nullable().optional(),
})
export const courseSchema = z
  .strictObject({
    name: plainText(160),
    durationMinutes: z.number().int().min(1).max(100_000),
    type: z.enum(['live', 'premade']),
    liveCallDurationMinutes: z.number().int().min(10).max(300).multipleOf(10).nullable(),
    certificateOnCompletion: z.boolean(),
    accessType: z.enum(['free', 'paid']),
    priceNaira: z.number().min(0).max(10_000_000),
    scheduledAt: z.iso.datetime().nullable().optional(),
    modules: z.array(moduleSchema).max(100),
    attachments: z.array(courseAttachmentSchema).max(10),
  })
  .refine((course) => course.type !== 'live' || course.liveCallDurationMinutes !== null, {
    path: ['liveCallDurationMinutes'],
    message: 'Choose a live class duration',
  })
  .refine(
    (course) =>
      (course.accessType === 'free' && course.priceNaira === 0) ||
      (course.accessType === 'paid' && course.priceNaira >= 0.01),
    {
      path: ['priceNaira'],
      message: 'Free courses must be zero; paid courses must cost at least one kobo',
    },
  )
  .refine((course) => hasKoboPrecision(course.priceNaira), {
    path: ['priceNaira'],
    message: 'Enter a price with no more than two decimal places',
  })
export const courseUpdateSchema = z
  .strictObject({
    name: plainText(160),
    durationMinutes: z.number().int().min(1).max(100_000),
    type: z.enum(['live', 'premade']),
    liveCallDurationMinutes: z.number().int().min(10).max(300).multipleOf(10).nullable(),
    certificateOnCompletion: z.boolean(),
    accessType: z.enum(['free', 'paid']),
    priceNaira: z.number().min(0).max(10_000_000),
    scheduledAt: z.iso.datetime().nullable(),
  })
  .refine((course) => course.type !== 'live' || course.liveCallDurationMinutes !== null, {
    path: ['liveCallDurationMinutes'],
    message: 'Choose a live class duration',
  })
  .refine(
    (course) =>
      (course.accessType === 'free' && course.priceNaira === 0) ||
      (course.accessType === 'paid' && course.priceNaira >= 0.01),
    {
      path: ['priceNaira'],
      message: 'Free courses must be zero; paid courses must cost at least one kobo',
    },
  )
  .refine((course) => hasKoboPrecision(course.priceNaira), {
    path: ['priceNaira'],
    message: 'Enter a price with no more than two decimal places',
  })
export const uploadSchema = z.strictObject({
  fileName: plainText(200),
  contentType: z.enum([
    'application/pdf',
    'image/jpeg',
    'image/png',
    'image/svg+xml',
    'image/gif',
    'image/webp',
    'video/mp4',
    'video/quicktime',
    'video/webm',
    'audio/mpeg',
    'audio/wav',
    'audio/mp4',
    'audio/ogg',
    'text/plain',
    'text/csv',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.ms-powerpoint',
    'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    'application/vnd.ms-excel',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'application/zip',
  ]),
  sizeBytes: z
    .number()
    .int()
    .min(1)
    .max(MAX_COURSE_UPLOAD_BYTES, 'Each file must be 1 GiB or smaller'),
})

const assessmentOptionSchema = z.strictObject({
  id: z.string().regex(/^[A-Za-z0-9_-]{1,100}$/),
  label: plainText(500),
})

const assessmentQuestionSchema = z
  .strictObject({
    prompt: plainText(5000),
    type: z.enum(['multiple_choice', 'free_text']),
    options: z.array(assessmentOptionSchema).max(6),
    correctOptionIds: z.array(z.string().regex(/^[A-Za-z0-9_-]{1,100}$/)).max(6),
    mediaType: z.enum(['image', 'video', 'audio']).nullable().optional(),
    mediaUrl: z
      .union([
        z.httpUrl().max(2048),
        z
          .string()
          .regex(/^courses\/[0-9A-HJKMNP-TV-Z]{26}\/[0-9A-HJKMNP-TV-Z]{26}\.(jpg|png|mp4|mp3)$/),
      ])
      .nullable()
      .optional(),
    points: z.number().int().min(1).max(1000),
  })
  .refine(
    (question) =>
      question.type === 'free_text' ||
      (question.options.length >= 2 && question.options.length <= 6),
    { message: 'Multiple-choice questions need between 2 and 6 options', path: ['options'] },
  )
  .refine((question) => question.type === 'multiple_choice' || question.options.length === 0, {
    message: 'Written questions cannot contain options',
    path: ['options'],
  })

export const assessmentSchema = z
  .strictObject({
    title: plainText(200),
    description: plainText(5000),
    courseId: idSchema.nullable().optional(),
    durationMinutes: z.number().int().min(1).max(1440),
    opensAt: z.iso.datetime(),
    closesAt: z.iso.datetime(),
    manualReview: z.boolean(),
    retrySupported: z.boolean(),
    maxAttempts: z.number().int().min(1).max(100),
    passingScorePercent: z.number().min(0).max(100),
    questions: z.array(assessmentQuestionSchema).min(1),
  })
  .refine((assessment) => new Date(assessment.closesAt) > new Date(assessment.opensAt), {
    message: 'Closing time must be after opening time',
    path: ['closesAt'],
  })
  .refine(
    (assessment) =>
      assessment.retrySupported
        ? assessment.maxAttempts >= 2 && assessment.maxAttempts <= 100
        : assessment.maxAttempts === 1,
    {
      message: 'Retry-enabled assessments must allow between 2 and 100 total attempts',
      path: ['maxAttempts'],
    },
  )

export const assessmentSubmissionSchema = z.strictObject({
  answers: z.array(
    z.strictObject({
      questionId: z.uuid(),
      selectedOptionIds: z
        .array(z.string().regex(/^[A-Za-z0-9_-]{1,100}$/))
        .max(6)
        .optional(),
      text: plainText(50_000).nullable().optional(),
    }),
  ),
})

export const assessmentReviewSchema = z.strictObject({
  grades: z
    .array(
      z.strictObject({
        questionId: z.uuid(),
        awardedPoints: z.number().min(0).max(1000),
        feedback: plainText(5000).nullable().optional(),
      }),
    )
    .min(1),
})

export const certificateEmailSchema = z.strictObject({ email: emailSchema })
